/*
 * Copyright (c) 2005-2006 by Cisco Systems, Inc.
 * All rights reserved.
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <time.h>
#include <errno.h>
#include <unistd.h>
#include <pthread.h>

#include "common.h"
#include "util.h"
#include "que.h"
#include "pool.h"
#include "ipc.h"


ipc_callback_t ipc_rx_callback;


int main (int argc, char** argv)
{
    int i;
    int err;
    uint32 ipc_port;

    if (argc < 2) {
        printf("Usage: %s <port_name1> <port_name2> ...\n", argv[0]);
        return EXIT_FAILURE;
    }

    err = ipc_init();
    if (err != IPC_OK) {
        return EXIT_FAILURE;
    }

    ipc_find_seat_manager();

    // Create ports
    for (i=1; i<argc; i++) {
        ipc_create_named_port(argv[i], &ipc_port, 0, IPC_CALLBACK,
                              (void*)i, &ipc_rx_callback);
    }

    // Register the last port
printf("ipc_create: register port %d\n", ipc_port);
    ipc_register_port(ipc_port);

    pthread_join(ipc_rx_thread, NULL);
    return EXIT_SUCCESS;
}


// Note: Don't know what err is for here!
//
void* ipc_rx_callback (server_msg_t *ipc_msg, void *context, int err)
{
//    printf("%d-Callback(%d): %.40s\n",
//           getpid(), (uint32)context, (char*)ipc_msg->data);

    if ((ipc_msg->header->flags & IPC_FLAG_IS_RPC)) {
        ipc_message* rpy_msg = ipc_get_pak_message(128, NULL, 0);
        if (rpy_msg == NULL) {
            fprintf(stderr, "Failed to allocate RPC reply message\n");
            return (void*)0;  // Note: this may leave the clinet blocked!
        }

        strcpy(rpy_msg->data, "Echo: ");
        strcpy(rpy_msg->data + 6, ipc_msg->data);
        err = ipc_send_rpc_reply_blocked(ipc_msg, rpy_msg);
        if (err != IPC_OK) {
            fprintf(stderr, "RPC reply failed.\n");
        }
    }

    server_msg_free(ipc_msg);
    return (void*)0;
}
