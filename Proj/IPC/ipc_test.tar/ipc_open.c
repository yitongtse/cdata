/*
 * Copyright (c) 2005-2006 by Cisco Systems, Inc.
 * All rights reserved.
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <time.h>
#include <pthread.h>
#include <unistd.h>

#include "common.h"
#include "que.h"
#include "pool.h"
#include "util.h"
#include "ipc.h"


int msg_size;
int msg_cnt;
ipc_port_info port_info;
boolean pause_flag = FALSE;
int send_cnt;
int ack_cnt;
// struct timespec ts = { 0, 1 };

uint64 start, stop;


void *notify_handler(client_msg_t* ipc_msg, void* context, int err)
{
#if 0
    ipc_message_header_t* ipc_hdr = ipc_msg->header;
    printf("open_port-Notify(%08x): %s %d-%d from port %d\n",
           (uint32)context, (err==IPC_OK? "ACK" : "NACK"),
           ipc_hdr->port_index, ipc_hdr->sequence, ipc_hdr->dest_port);
#endif

    if (err == IPC_OK) {
        ack_cnt++;
        if (ack_cnt == msg_cnt) {
            printf("Successfully sent %d messages.\n", msg_cnt);
            exit (EXIT_SUCCESS);
        }

    } else {
        printf("open_port: Failed to send message %d.\n",
               ipc_msg->header->sequence);
        exit (EXIT_FAILURE);
    }

    return (void*)NULL;
}


int main (int argc, char** argv)
{
    ipc_error_code err;
    int mode;
    ipc_message *ipc_msg;
    server_msg_t *rpc_resp;

    if (argc != 5) {
        printf("Usage: %s <port_name> <msg_size> <msg_count> <mode>\n\n",
               argv[0]);
        printf("Mode: 1 - Unreliable\n");
        printf("      2 - Reliable non-blocking\n");
        printf("      3 - Reliable blocking\n");
        printf("      4 - Reliable blocking RPC\n");

        exit (EXIT_FAILURE);
    }

    ipc_init();
    ipc_find_seat_manager();

    mode = (boolean)atoi(argv[4]);

    // Open a session
    port_info.notify_callback = notify_handler;
    port_info.notify_context = &port_info;

    switch (mode) {
    case 1:
        port_info.port_features = IPC_PORT_FEAT_UNREL;
        break;

    case 2:
    case 3:
    case 4:
        port_info.port_features = IPC_PORT_FEAT_RELIABLE;
        break;

    default:
        printf("Unknown mode %d\n", mode);
        exit (EXIT_FAILURE);
    }

    err = ipc_open_port_by_name(argv[1], &port_info);
    if (err != IPC_OK) {
        printf("ipc_open: Failed to open port %s\n", argv[1]);
        exit (EXIT_FAILURE);
    }

    msg_size = atoi(argv[2]);
    msg_cnt = atoi(argv[3]);
    send_cnt = 0;
    ack_cnt = 0;

    ClockTime(CLOCK_REALTIME, NULL, &start);

    while (1) {
        // Check whether we are done
        if (send_cnt >= msg_cnt) {
            break;
        }

        // Allocate message buffer
        ipc_msg = ipc_get_pak_message(msg_size, &port_info, 0);    
        if (ipc_msg == NULL) {
            // Yield to other thread if allocation failed
            SchedYield();
            continue;
        }

        // Send message
        send_cnt++;
        sprintf(ipc_msg->data, "Message %d", send_cnt);

        switch (mode) {
        case 1: // Unreliable mode
//            printf("\nopen_port: send unreliable msg %d\n", send_cnt);
            err = ipc_send_message(ipc_msg, &port_info);
            break;

        case 2: // Reliable non-blocking mode
//            printf("\nopen_port: send reliable non-blocked msg %d\n",
//                   send_cnt);
            err = ipc_send_message(ipc_msg, &port_info);
            break;

        case 3: // Reliable blocking mode
//            printf("\nopen_port: send reliable blocked msg %d\n", send_cnt);
            err = ipc_send_message_blocked(ipc_msg, &port_info);
            break;

        case 4: // Reliable RPC blocking mode
//            printf("\nopen_port: send reliable blocked RPC %d\n", send_cnt);
            rpc_resp = ipc_send_rpc_blocked(&port_info, ipc_msg, &err);
//            printf("RPC response: %s\n", (char*)rpc_resp->data);
            ipc_return_message(rpc_resp);
            break;
        }

        if (mode != 2) {
            if (err == IPC_OK) {
                ack_cnt = send_cnt;
                if (ack_cnt == msg_cnt) {
                    ClockTime(CLOCK_REALTIME, NULL, &stop);
                    printf("Benchmark: %.2f us per message\n",
                           (stop-start)/1000./msg_cnt);
                    printf("Successfully sent %d messages.\n", msg_cnt);
                    exit (EXIT_SUCCESS);
                }

            } else {
                printf("open_port: Failed to send message %d.\n", send_cnt);
                exit (EXIT_FAILURE); 
            }
        }

//          sleep(3);
    }

    ClockTime(CLOCK_REALTIME, NULL, &stop);
    printf("Benchmark: %.2f us per message\n", (stop-start)/1000./msg_cnt);

    while (1) {
        sleep(1);
    }

    exit (EXIT_SUCCESS);
}
