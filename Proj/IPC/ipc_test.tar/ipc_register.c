/*
 * Copyright (c) 2005-2006 by Cisco Systems, Inc.
 * All rights reserved.
 */

#include <errno.h>
#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include "common.h"
#include "util.h"
#include "que.h"
#include "pool.h"
#include "ipc.h"


char buf[IPC_MESSAGE_MAX_MTU];
int seq_no;

#if 0
char *port_name = "GALIOS IPC:TEST";
uint16 port_id = 0x02030010;
#endif

char full_port_name[128];


void send_register (ipc_port_id port_id, char *port_name)
{
    int fd;
    ipc_message_header_t *ipc_hdr;
    ipc_register_name_request *msg;

    ipc_hdr = (ipc_message_header_t*)buf;
    ipc_hdr->length = 32;
    ipc_hdr->ver = 0;
    ipc_hdr->dest_port = 0x00010003;	// IPC Master:Control
    ipc_hdr->source_port = 0x02030001;
    ipc_hdr->port_index = 0;
    ipc_hdr->sequence = seq_no;
    ipc_hdr->type = IPC_TYPE_REGISTER_NAME_REQUEST;
    ipc_hdr->size = 64;
//    ipc_hdr->flags = IPC_FLAG_DO_NOT_ACK | IPC_FLAG_CONTROL;
    ipc_hdr->flags = IPC_FLAG_IS_RPC | IPC_FLAG_CONTROL;
			// IPC_FLAG_CONTROL must be set for control messages!
    ipc_hdr->msg_id_hi = 0;
    ipc_hdr->msg_id_lo = 0;

    msg = (ipc_register_name_request*)(buf + 32);
    msg->port_id = port_id;
    msg->name_length = strlen(port_name);
    strcpy(msg->name, port_name);

    fd = open("/ipc/cipc", O_WRONLY);
    write(fd, buf, 64);
    close(fd);
}


int main(int argc, char **argv)
{
    int err;
    uint16 port_id;

    if (argc != 3) {
        fprintf(stderr, "Usage: ipc_register <port_id> <seq_no>\n");
        exit (-1);
    }

    port_id = atoi(argv[1]);
    seq_no = atoi(argv[2]);

    err = ipc_init();
    if (err != IPC_OK) {
        return EXIT_FAILURE;
    }

    ipc_find_seat_manager();


#if 0
    sprintf(full_port_name, "RFGW : %s", "test_port");
    send_register(port_id, full_port_name);
#else
    ipc_register_port(port_id);
#endif

    return EXIT_SUCCESS;
}

