/*
 * Copyright (c) 2005-2006 by Cisco Systems, Inc.
 * All rights reserved.
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <time.h>
#include <pthread.h>
#include <unistd.h>

#include "common.h"
#include "que.h"
#include "pool.h"
#include "util.h"
#include "ipc.h"


#define	MSG_SIZE	64

char test_message[MSG_SIZE];
ipc_port_info port_info;


int main (int argc, char** argv)
{
    ipc_message *message;
    server_msg_t *response;
    ipc_error_code err;
    int msg_cnt;
    int i;

    if (argc != 3) {
        printf("Usage: %s <port_name> <msg_count>\n", argv[0]);
        return EXIT_FAILURE;
    }

    msg_cnt = atoi(argv[2]);
    ipc_init();
    ipc_find_seat_manager();

    port_info.port_features = IPC_PORT_FEAT_RELIABLE;
    err = ipc_open_port_by_name(argv[1], &port_info);
    if (err != IPC_OK) {
        printf("Failed to open RPC test port\n");
        return EXIT_FAILURE;
    }

    for (i=1; i<=msg_cnt; i++) {
        message = ipc_get_pak_message(MSG_SIZE, &port_info,
                                      IPC_TYPE_SERVER_ECHO);
        sprintf(message->data, "RPC test %d", i);
        printf("RPC request : %s\n", (char*)message->data);

        response = ipc_send_rpc_blocked(&port_info, message, &err);
        if (err != IPC_OK) {
            printf("RPC test failed\n");
            return EXIT_FAILURE;
        }

        printf("RPC response: %s\n", (char*)response->data);
        ipc_return_message(response);

        sleep(1);
    }

//  ipc_close_port(&port_info);

    return EXIT_SUCCESS;
}
